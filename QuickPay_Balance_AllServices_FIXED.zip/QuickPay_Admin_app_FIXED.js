import { initializeApp } from "https://www.gstatic.com/firebasejs/11.10.0/firebase-app.js";
import {
  getAuth, signInWithEmailAndPassword, signOut, onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/11.10.0/firebase-auth.js";
import {
  getFirestore, collection, doc, addDoc, setDoc, updateDoc, deleteDoc,
  onSnapshot, query, orderBy, limit, serverTimestamp, getDoc, where,
  runTransaction
} from "https://www.gstatic.com/firebasejs/11.10.0/firebase-firestore.js";

/*
  Quick Pay Firebase Web configuration.
  These values are Firebase client configuration, not service-account secrets.
  Project information is taken from the Android Firebase project.
*/
const firebaseConfig = {
  apiKey: "AIzaSyBom1sRP1kRdoOOpMhpb1pAUPmLuqNfKHY",
  authDomain: "quick-pay-21314.firebaseapp.com",
  projectId: "quick-pay-21314",
  storageBucket: "quick-pay-21314.firebasestorage.app",
  messagingSenderId: "748708771713",
  appId: "1:748708771713:web:a856d3e7807e2852c15a80",
  measurementId: "G-ZD8358PM7D"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

const $ = id => document.getElementById(id);
const esc = s => String(s ?? "").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#039;"}[m]));
const money = v => "৳ " + Number(v || 0).toLocaleString("bn-BD",{minimumFractionDigits:2,maximumFractionDigits:2});
const nowText = () => new Date().toLocaleString("bn-BD");
const col = name => collection(db,name);
const ops=["গ্রামীণফোন","বাংলালিংক","Robi","Airtel","Teletalk"];
let selectedOperator="গ্রামীণফোন";
let currentPage="dashboard";
let cache={users:[],transactions:[],depositRequests:[],serviceRequests:[],offers:[],chat:[],live:[],reviews:[],tutorials:[],settings:null};
let unsub=[];
let editingUser=null;

$("fbStatus").textContent="Firebase Ready";
$("fbStatus").className="firebase-status ok";

function toast(msg){
  const x=document.createElement("div"); x.className="toast"; x.textContent=msg;
  document.body.appendChild(x); setTimeout(()=>x.remove(),2500);
}
function stat(i,l,v){return `<div class="stat"><div class="icon">${i}</div><div class="value">${esc(v)}</div><div class="label">${l}</div></div>`}
function field(id,label,value){return `<div class="field"><label>${label}</label><input id="${id}" value="${esc(value)}"></div>`}

async function isAdmin(user){
  if(!user) return false;
  const snap=await getDoc(doc(db,"admins",user.uid));
  if(!snap.exists()) return false;
  const data = snap.data() || {};
  return data.role === "admin" || data.active === true;
}
async function login(){
  const email=$("adminEmail").value.trim(), pass=$("adminPass").value;
  if(!email||!pass){alert("Admin Email ও Password দিন");return}
  try{
    const cred=await signInWithEmailAndPassword(auth,email,pass);
    if(!(await isAdmin(cred.user))){
      await signOut(auth); alert("এই Firebase account-এর Admin permission নেই। Firebase Console-এ admins collection-এ UID যোগ করুন.");
    }
  }catch(e){alert("Login failed: "+(e.code||e.message))}
}
async function logout(){await signOut(auth)}
$("loginBtn").onclick=login; $("logoutBtn").onclick=logout; $("menuBtn").onclick=()=>document.querySelector(".sidebar").classList.toggle("open");

onAuthStateChanged(auth, async user=>{
  if(!user){showLogin();return}
  try{
    if(await isAdmin(user)){showApp();startListeners();render("dashboard")}
    else {await signOut(auth);showLogin()}
  }catch(e){console.error(e);await signOut(auth);showLogin()}
});
function showLogin(){$("loginView").classList.remove("hidden");$("appView").classList.add("hidden")}
function showApp(){$("loginView").classList.add("hidden");$("appView").classList.remove("hidden")}

function stopListeners(){unsub.forEach(x=>x&&x());unsub=[]}
function startListeners(){
  stopListeners();
  const listen=(name,queryRef,mapper)=>unsub.push(onSnapshot(queryRef,s=>{cache[name]=s.docs.map(d=>({id:d.id,...d.data()}));render(currentPage)},e=>console.error(name,e)));
  listen("users",col("users"),x=>x);
  listen("transactions",query(col("transactions"),orderBy("createdAt","desc"),limit(500)),x=>x);
  listen("depositRequests",query(col("depositRequests"),orderBy("createdAt","desc"),limit(500)),x=>x);
  listen("serviceRequests",query(col("serviceRequests"),orderBy("createdAt","desc"),limit(500)),x=>x);
  listen("offers",col("offers"),x=>x);
  listen("chat",query(col("chatMessages"),orderBy("createdAt","desc"),limit(500)),x=>x);
  listen("live",col("liveActivities"),x=>x);
  listen("reviews",col("reviews"),x=>x);
  listen("tutorials",col("tutorials"),x=>x);
  unsub.push(onSnapshot(doc(db,"settings","general"),s=>{cache.settings=s.exists()?s.data():{};render(currentPage)},e=>console.error("settings",e)));
}

const pages={
dashboard:()=>`<div class="cards">
${stat("👥","মোট ইউজার",cache.users.length)}
${stat("⏳","Pending Add Money",cache.depositRequests.filter(x=>String(x.status||"").toUpperCase()==="PENDING").length)}
${stat("⭐","সক্রিয় অফার",cache.offers.filter(x=>x.active!==false).length)}
${stat("💬","Pending Chat",cache.chat.filter(x=>["Pending","PENDING"].includes(x.status)).length)}
</div>
<div class="panel"><h3>Quick Pay Control Center</h3>
<p>Firebase-এর সাথে realtime sync চালু আছে। User, Balance, Add Money, Transaction এবং Group Chat এখান থেকেই নিয়ন্ত্রণ করুন।</p>
<div class="notice">🔐 Balance lock, Add Money approval এবং Chat approval-এর নিয়ম অবশ্যই Firestore Rules/Android backend-এও enforce করতে হবে।</div></div>`,
offers:()=>`<div class="panel"><h3>⭐ Special Offer Management</h3>
<div class="operator-tabs">${ops.map(o=>`<button class="${o===selectedOperator?"active":""}" data-op="${esc(o)}">${esc(o)}</button>`).join("")}</div>
<div class="actions"><button class="primary" id="addOffer">+ অফার যোগ করুন</button></div>
${cache.offers.filter(o=>o.operator===selectedOperator).map(o=>offerCard(o)).join("")||'<div class="empty">এই Operator-এর কোনো অফার নেই।</div>'}</div>`,
live:()=>`<div class="panel">
<h3>🔴 Live Activity Control</h3>
<div class="notice">এটি Admin-controlled Live Activity। এটি আসল User Transaction-এর সাথে যুক্ত নয়। সর্বোচ্চ ৫০০টি Activity রাখা যাবে এবং App-এ একটার পর একটা Auto Rotate করার জন্য data প্রস্তুত থাকবে।</div>
<div class="live-control-grid">
  <div class="live-setting">
    <label>Auto Rotate Interval</label>
    <select id="liveInterval">
      ${[3,5,7,10,15,20,30].map(n=>`<option value="${n}" ${Number(cache.settings?.liveRotateSeconds||5)===n?"selected":""}>${n} সেকেন্ড</option>`).join("")}
    </select>
  </div>
  <div class="live-setting">
    <label>Live Display</label>
    <select id="liveEnabled">
      <option value="true" ${cache.settings?.liveEnabled!==false?"selected":""}>ON</option>
      <option value="false" ${cache.settings?.liveEnabled===false?"selected":""}>OFF</option>
    </select>
  </div>
</div>
<div class="actions">
  <button class="primary" id="saveLiveSettings">Save Live Settings</button>
  <button class="secondary" id="addLive">+ Activity যোগ করুন</button>
  <span class="live-count">${cache.live.length}/500</span>
</div>
<div class="live-preview">
  <div class="live-preview-title">APP PREVIEW</div>
  <div id="livePreviewBox">${renderLivePreview()}</div>
</div>
<div class="live-list">
${cache.live.map((x,i)=>`<div class="live-row">
  <span class="live-number">${i+1}</span>
  <span class="live-dot">● LIVE</span>
  <div class="grow">
    <b>${esc(x.name||"User")}</b>
    <div>${esc(x.text||"")}</div>
    <small>${esc(x.phone||"")} • ${money(x.amount||0)} • ${esc(x.type||"")}</small>
  </div>
  <span class="tag">${x.active!==false?"Active":"Hidden"}</span>
  <button class="secondary" onclick="editLive('${x.id}')">Edit</button>
  <button class="secondary" onclick="toggleLive('${x.id}',${x.active!==false})">${x.active!==false?"Hide":"Show"}</button>
  <button class="danger" onclick="delLive('${x.id}')">Delete</button>
</div>`).join("")||'<div class="empty">কোনো Live Activity নেই। Activity যোগ করুন।</div>'}
</div>
</div>`,
banner:()=>`<div class="panel"><h3>🖼️ Deposit Bonus Banner</h3><div class="grid">
${field("bannerImage","Banner Image URL",cache.settings?.bannerImage||"")}${field("bannerLink","Click Link",cache.settings?.bannerLink||"")}
<div class="field"><label><input type="checkbox" id="bannerActive" ${cache.settings?.bannerActive?"checked":""}> Active</label></div></div>
<div class="actions"><button class="primary" id="saveBanner">Save Banner</button></div>${cache.settings?.bannerImage?`<img class="preview" src="${esc(cache.settings.bannerImage)}">`:""}</div>`,
users:()=>`<div class="panel"><div class="panel-head"><h3>👥 Users & Balance Control</h3><button class="primary" id="addUser">+ User</button></div>
<div class="filters"><input id="userSearch" placeholder="Name / phone / User ID"><select id="userStatus"><option value="">সব Account</option><option value="active">Active</option><option value="blocked">Blocked</option></select></div>
<div class="table-wrap"><table class="table"><thead><tr><th>User</th><th>Main</th><th>Drive</th><th>Account</th><th>Actions</th></tr></thead><tbody id="userBody"></tbody></table></div></div>`,
transactions:()=>`<div class="panel"><div class="panel-head"><h3>💰 Add Money Requests</h3><span class="tag">Pending ${cache.depositRequests.filter(x=>String(x.status||"").toUpperCase()==="PENDING").length}</span></div>
<div class="table-wrap"><table class="table"><thead><tr><th>User</th><th>Amount</th><th>Method</th><th>Reference</th><th>Date</th><th>Status</th><th>Action</th></tr></thead><tbody>${cache.depositRequests.map(r=>`<tr><td><b>${esc(r.name||"")}</b><br><small>${esc(r.phone||r.uid||"")}</small></td><td>${money(r.amount)}</td><td>${esc(r.method||"")}</td><td>${esc(r.transactionId||r.reference||"")}</td><td>${esc(fmtDate(r.createdAt))}</td><td>${esc(r.status||"")}</td><td>${String(r.status||"").toUpperCase()==="PENDING"?`<button class="primary mini" onclick="approveDeposit('${r.id}')">Confirm</button> <button class="danger mini" onclick="rejectDeposit('${r.id}')">Reject</button>`:"—"}</td></tr>`).join("")||'<tr><td colspan="7" class="empty">কোনো Add Money request নেই।</td></tr>'}</tbody></table></div></div>
<div class="panel"><div class="panel-head"><h3>📤 Service / Cash Out Requests</h3><span class="tag">Pending ${cache.serviceRequests.filter(x=>String(x.status||"").toUpperCase()==="PENDING").length}</span></div>
<div class="table-wrap"><table class="table"><thead><tr><th>User</th><th>Type</th><th>Details</th><th>Amount</th><th>Date</th><th>Status</th><th>Action</th></tr></thead><tbody>
${cache.serviceRequests.map(r=>`<tr><td><b>${esc(r.name||"")}</b><br><small>${esc(r.phone||r.uid||"")}</small></td><td>${esc(r.type||"")}</td><td>${esc(r.detail||"")}</td><td>${money(r.amount)}</td><td>${esc(fmtDate(r.createdAt))}</td><td>${esc(r.status||"")}</td><td>${String(r.status||"").toUpperCase()==="PENDING"?`<button class="primary mini" onclick="approveServiceRequest('${r.id}')">Approve</button> <button class="danger mini" onclick="rejectServiceRequest('${r.id}')">Reject + Refund</button>`:"—"}</td></tr>`).join("")||'<tr><td colspan="7" class="empty">কোনো Service Request নেই।</td></tr>'}</tbody></table></div></div>
<div class="panel"><div class="panel-head"><h3>🧾 All Transaction History</h3></div>
<div class="filters"><input id="txSearch" placeholder="User / phone / details / reference"><select id="txType"><option value="">সব Type</option><option>অ্যাড মানি</option><option>Add Money</option><option>Mobile Banking</option><option>Bank Transfer</option><option>Mobile Recharge</option><option>Bill Pay</option><option>Special Offer</option><option>Invite Bonus</option></select><select id="txStatus"><option value="">সব Status</option><option>PENDING</option><option>Pending</option><option>APPROVED</option><option>Approved</option><option>REJECTED</option><option>Rejected</option><option>Success</option></select></div>
<div class="table-wrap"><table class="table"><thead><tr><th>Type</th><th>User</th><th>Details</th><th>Amount</th><th>Date</th><th>Status</th><th>Action</th></tr></thead><tbody id="txBody"></tbody></table></div></div>`,
invite:()=>`<div class="panel"><h3>🎁 Invite Bonus</h3><div class="grid">${field("inviteAmount","Bonus Amount",cache.settings?.inviteAmount||"")}${field("inviteActive","",cache.settings?.inviteActive?"":"")}
<div class="field"><label><input id="inviteEnabled" type="checkbox" ${cache.settings?.inviteActive!==false?"checked":""}> Active</label></div>
<div class="field full"><label>Rules / Description</label><textarea id="inviteRules">${esc(cache.settings?.inviteRules||"")}</textarea></div></div><div class="actions"><button class="primary" id="saveInvite">Save</button></div></div>`,
care:()=>`<div class="panel"><h3>🎧 Customer Care</h3>${field("careWhatsapp","WhatsApp Number",cache.settings?.careWhatsapp||"")}<div class="actions"><button class="primary" id="saveCare">Save</button></div></div>`,
reviews:()=>mediaPage("⭐ Customer Reviews","reviews"),
tutorials:()=>mediaPage("▶️ Video Tutorials","tutorials"),
about:()=>`<div class="panel"><h3>ℹ️ About Us</h3><div class="grid">
${field("aboutName","প্রতিষ্ঠানের নাম",cache.settings?.aboutName||"")}${field("aboutLicense","লাইসেন্স/রেজিস্ট্রেশন",cache.settings?.aboutLicense||"")}${field("aboutAddress","ঠিকানা",cache.settings?.aboutAddress||"")}${field("aboutPhone","যোগাযোগ",cache.settings?.aboutPhone||"")}
<div class="field full"><label>পরিচিতি</label><textarea id="aboutIntro">${esc(cache.settings?.aboutIntro||"")}</textarea></div>
<div class="field full"><label>বিস্তারিত তথ্য</label><textarea id="aboutDetails">${esc(cache.settings?.aboutDetails||"")}</textarea></div></div><div class="actions"><button class="primary" id="saveAbout">Save</button></div></div>`,
chat:()=>`<div class="panel"><div class="panel-head"><h3>💬 Group Chat Approval</h3><span class="tag">Pending ${cache.chat.filter(x=>["Pending","PENDING"].includes(x.status)).length}</span></div>
<p>ইউজার মেসেজ পাঠাবে, কিন্তু Admin Approve না করা পর্যন্ত অন্য User দেখতে পাবে না।</p><h4>Pending Messages</h4>
${cache.chat.filter(m=>["Pending","PENDING"].includes(m.status)).map(m=>`<div class="chat-row"><div class="grow"><b>${esc(m.name||"User")}</b> <small>${esc(m.userId||"")} • ${esc(fmtDate(m.createdAt))}</small><div class="bubble">${esc(m.message)}</div></div><button class="primary" onclick="approveChat('${m.id}')">Approve</button><button class="danger" onclick="rejectChat('${m.id}')">Reject</button></div>`).join("")||'<div class="empty">Pending message নেই।</div>'}
<h4>Approved Messages</h4>${cache.chat.filter(m=>["Approved","APPROVED"].includes(m.status)).slice(0,100).map(m=>`<div class="approved-row"><b>${esc(m.name||"User")}</b><small>${esc(fmtDate(m.approvedAt||m.createdAt))}</small><div>${esc(m.message)}</div></div>`).join("")||'<div class="empty">Approved message নেই।</div>'}</div>`,
paymentNumbers:()=>`<div class="panel">
<h3>💳 Payment Numbers</h3>
<div class="notice">Add Money-এর সময় অ্যাপে যে bKash, Nagad ও Rocket নম্বর দেখাবে, এখান থেকেই পরিবর্তন করুন। Save করার পর Firebase-এ নতুন নম্বর সংরক্ষণ হবে।</div>
<div class="grid">
  ${field("bkashNumber","bKash Number",cache.settings?.bkashNumber||"")}
  <div class="field"><label><input type="checkbox" id="bkashVisible" ${cache.settings?.bkashVisible!==false?"checked":""}> bKash নম্বর অ্যাপে দেখাবে</label></div>
  ${field("nagadNumber","Nagad Number",cache.settings?.nagadNumber||"")}
  <div class="field"><label><input type="checkbox" id="nagadVisible" ${cache.settings?.nagadVisible!==false?"checked":""}> Nagad নম্বর অ্যাপে দেখাবে</label></div>
  ${field("rocketNumber","Rocket Number",cache.settings?.rocketNumber||"")}
  <div class="field"><label><input type="checkbox" id="rocketVisible" ${cache.settings?.rocketVisible!==false?"checked":""}> Rocket নম্বর অ্যাপে দেখাবে</label></div>
</div>
<div class="actions"><button class="primary" id="savePaymentNumbers">Save Payment Numbers</button></div>
</div>`,
settings:()=>`<div class="panel"><h3>⚙️ Settings</h3><p>Firebase project: <b>quick-pay-21314</b></p><p>Admin access Firebase Authentication + <code>admins/{uid}</code> document দিয়ে নিয়ন্ত্রিত।</p><div class="notice">Admin UID-কে <b>admins</b> collection-এ document ID হিসেবে যোগ করুন। field: <b>active: true</b>.</div><div class="actions"><button class="secondary" id="reload">Reload Firebase</button></div></div>`
};

function fmtDate(v){
 if(!v)return "";
 if(typeof v==="string")return v;
 if(v.seconds)return new Date(v.seconds*1000).toLocaleString("bn-BD");
 if(v.toDate)return v.toDate().toLocaleString("bn-BD");
 return String(v);
}
function mediaPage(title,type){
 const arr=cache[type]||[];
 return `<div class="panel"><h3>${title}</h3><div class="actions"><button class="primary" onclick="addMedia('${type}')">+ যোগ করুন</button></div>
 ${arr.map(x=>`<div class="offer-card"><div class="offer-head"><b>${esc(x.title)}</b><span class="tag">${x.active!==false?"Active":"Hidden"}</span></div><p>${esc(x.url||"")}</p><button class="secondary" onclick="toggleMedia('${type}','${x.id}',${x.active!==false})">Show/Hide</button> <button class="danger" onclick="deleteMedia('${type}','${x.id}')">Delete</button></div>`).join("")||'<div class="empty">কোনো item নেই।</div>'}</div>`
}
function offerCard(o){return `<div class="offer-card"><div class="offer-head"><b>${esc(o.offer_name||o.operator)}</b><span class="offer-price">৳${esc(o.price||0)}</span></div><p>${esc(o.data||"")} ${esc(o.minutes||"")} ${esc(o.sms||"")} ${o.validity?"• "+esc(o.validity):""}</p><p>বোনাস: ৳${esc(o.bonus||0)}</p><span class="tag">${o.active!==false?"Active":"Hidden"}</span> <button class="secondary" onclick="editOffer('${o.id}')">Edit</button> <button class="danger" onclick="deleteOffer('${o.id}')">Delete</button></div>`}

function render(page){
 currentPage=page;
 document.querySelectorAll(".nav").forEach(n=>n.classList.toggle("active",n.dataset.page===page));
 const titles={dashboard:"Dashboard",offers:"Special Offers",live:"Live Activity",banner:"Deposit Bonus",users:"Users",transactions:"Transactions",invite:"Invite Bonus",care:"Customer Care",reviews:"Customer Reviews",tutorials:"Video Tutorials",about:"About Us",chat:"Group Chat Approval",paymentNumbers:"Payment Numbers",settings:"Settings"};
 $("pageTitle").textContent=titles[page]||page; $("page").innerHTML=(pages[page]||pages.dashboard)(); bindPage(page);
 document.querySelector(".sidebar").classList.remove("open");
 if(page==="users")renderUsers(); if(page==="transactions")renderTransactions();
}
document.querySelectorAll(".nav").forEach(n=>n.onclick=()=>render(n.dataset.page));

function bindPage(page){
 if(page==="offers"){document.querySelectorAll("[data-op]").forEach(b=>b.onclick=()=>{selectedOperator=b.dataset.op;render("offers")});$("addOffer").onclick=()=>openOffer()}
 if(page==="live"){
  $("addLive").onclick=addLive;
  $("saveLiveSettings").onclick=saveLiveSettings;
  $("liveInterval").onchange=()=>{};
  $("liveEnabled").onchange=()=>{};
}
 if(page==="banner")$("saveBanner").onclick=saveBanner;
 if(page==="users"){$("addUser").onclick=addUser;$("userSearch").oninput=renderUsers;$("userStatus").onchange=renderUsers}
 if(page==="transactions"){$("txSearch").oninput=renderTransactions;$("txType").onchange=renderTransactions;$("txStatus").onchange=renderTransactions}
 if(page==="invite")$("saveInvite").onclick=saveInvite;
 if(page==="care")$("saveCare").onclick=saveCare;
 if(page==="about")$("saveAbout").onclick=saveAbout;
 if(page==="paymentNumbers")$("savePaymentNumbers").onclick=savePaymentNumbers;
 if(page==="settings")$("reload").onclick=()=>location.reload();
}
function renderUsers(){
 const q=($("userSearch")?.value||"").toLowerCase(), st=$("userStatus")?.value||"";
 $("userBody").innerHTML=cache.users.filter(u=>!st||(st==="active"?(u.active!==false):(u.active===false))).filter(u=>JSON.stringify(u).toLowerCase().includes(q)).map(u=>`<tr>
 <td><b>${esc(u.name||"Unnamed")}</b><br><small>${esc(u.phone||"")} • ${esc(u.id)}</small></td>
 <td>${money(u.mainBalance)} ${(u.mainLocked||u.mainBalanceLocked)?"🔒":""}</td><td>${money(u.driveBalance)} ${(u.driveLocked||u.driveBalanceLocked)?"🔒":""}</td>
 <td><span class="tag ${u.active===false?"redtag":""}">${u.active===false?"Blocked":"Active"}</span></td>
 <td><button class="secondary" onclick="viewUser('${u.id}')">Profile</button></td></tr>`).join("")||'<tr><td colspan="5" class="empty">User data নেই।</td></tr>'
}
function userFor(t){return cache.users.find(u=>u.id===t.userId)||cache.users.find(u=>u.uid===t.userId)}
function renderTransactions(){
 const q=($("txSearch")?.value||"").toLowerCase(),type=$("txType")?.value||"",status=$("txStatus")?.value||"";
 $("txBody").innerHTML=cache.transactions.filter(t=>!type||t.type===type).filter(t=>!status||String(t.status||"")===status).filter(t=>JSON.stringify({...t,user:userFor(t)}).toLowerCase().includes(q)).map(t=>{
  const u=userFor(t), inTx=t.credit===true||t.in===true||["Add Money","অ্যাড মানি","Invite Bonus","ইনভাইট বোনাস"].includes(t.type);
  return `<tr><td>${esc(t.type||"")}</td><td>${esc(u?.name||t.name||t.userId||t.uid||"")}<br><small>${esc(u?.phone||t.phone||"")}</small></td><td>${esc(t.detail||t.details||t.description||t.reference||"")}</td><td class="${inTx?"in":""}">${inTx?"+":"-"}${money(t.amount)}</td><td>${esc(fmtDate(t.createdAt||t.date))}</td><td><span class="tag ${["Rejected","REJECTED"].includes(t.status)?"redtag":""}">${esc(t.status||"")}</span></td><td>—</td></tr>`
 }).join("")||'<tr><td colspan="7" class="empty">কোনো লেনদেন পাওয়া যায়নি।</td></tr>'
}
async function approveDeposit(id){
 const r=cache.depositRequests.find(x=>x.id===id); if(!r||String(r.status||"").toUpperCase()!=="PENDING")return;
 if(!r.uid){alert("এই request-এ user UID নেই।");return}
 try{
  await runTransaction(db,async tx=>{
   const rr=doc(db,"depositRequests",id), rs=await tx.get(rr);
   if(!rs.exists()||String(rs.data().status||"").toUpperCase()!=="PENDING")throw new Error("Request already processed");
   const ur=doc(db,"users",r.uid), us=await tx.get(ur);
   if(!us.exists())throw new Error("User profile not found");
   const u=us.data(), old=Math.max(0,Number(u.mainBalance||0)), amount=Math.max(0,Number(r.amount||0));
   tx.update(ur,{mainBalance:old+amount,updatedAt:serverTimestamp()});
   tx.update(rr,{status:"APPROVED",approvedAt:serverTimestamp()});
   const tr=doc(col("transactions"));
   tx.set(tr,{uid:r.uid,userId:r.uid,name:r.name||u.name||"",phone:r.phone||u.phone||"",type:"অ্যাড মানি",detail:"ডিপোজিট / "+(r.transactionId||r.reference||""),amount,credit:true,status:"APPROVED",createdAt:serverTimestamp(),sourceRequestId:id});
  });
  toast("Add Money Confirm হয়েছে");
 }catch(e){alert("Confirm failed: "+e.message)}
}
async function rejectDeposit(id){try{await updateDoc(doc(db,"depositRequests",id),{status:"REJECTED",rejectedAt:serverTimestamp()});toast("Add Money Rejected")}catch(e){alert(e.message)}}
window.approveDeposit=approveDeposit;window.rejectDeposit=rejectDeposit;

async function approveServiceRequest(id){
 const r=cache.serviceRequests.find(x=>x.id===id); if(!r||String(r.status||"").toUpperCase()!=="PENDING")return;
 try{
  await runTransaction(db,async tx=>{
   const rr=doc(db,"serviceRequests",id), rs=await tx.get(rr);
   if(!rs.exists()||String(rs.data().status||"").toUpperCase()!=="PENDING")throw new Error("Request already processed");
   const d=rs.data();
   tx.update(rr,{status:"APPROVED",approvedAt:serverTimestamp()});
   for(const c of ["mobileBankingRequests","bankTransferRequests","rechargeRequests","billPayRequests","specialOfferRequests"]){
    const sr=doc(db,c,id);
    tx.set(sr,{status:"APPROVED",approvedAt:serverTimestamp()},{merge:true});
   }
  });
  const q=query(col("transactions"),where("sourceRequestId","==",id),limit(10));
  const snap=await new Promise((resolve,reject)=>{const off=onSnapshot(q,s=>{off();resolve(s)},e=>{off();reject(e)})});
  for(const d of snap.docs) await updateDoc(d.ref,{status:"APPROVED",approvedAt:serverTimestamp()});
  toast("Request Approved — balance already deducted");
 }catch(e){alert("Approve failed: "+e.message)}
}

async function rejectServiceRequest(id){
 const r=cache.serviceRequests.find(x=>x.id===id); if(!r||String(r.status||"").toUpperCase()!=="PENDING")return;
 if(!confirm("রিকোয়েস্ট Reject করলে কাটা টাকা User-এর Main Balance-এ ফেরত যাবে। চালিয়ে যাবেন?"))return;
 try{
  await runTransaction(db,async tx=>{
   const rr=doc(db,"serviceRequests",id), rs=await tx.get(rr);
   if(!rs.exists()||String(rs.data().status||"").toUpperCase()!=="PENDING")throw new Error("Request already processed");
   const d=rs.data(), amount=Math.max(0,Number(d.amount||0));
   const ur=doc(db,"users",d.uid), us=await tx.get(ur);
   if(!us.exists())throw new Error("User profile not found");
   const old=Math.max(0,Number(us.data().mainBalance||0));
   tx.update(ur,{mainBalance:old+amount,updatedAt:serverTimestamp()});
   tx.update(rr,{status:"REJECTED",rejectedAt:serverTimestamp(),refunded:true});
   for(const c of ["mobileBankingRequests","bankTransferRequests","rechargeRequests","billPayRequests","specialOfferRequests"]){
    const sr=doc(db,c,id); tx.set(sr,{status:"REJECTED",rejectedAt:serverTimestamp(),refunded:true},{merge:true});
   }
  });
  const q=query(col("transactions"),where("sourceRequestId","==",id),limit(10));
  const snap=await new Promise((resolve,reject)=>{const off=onSnapshot(q,s=>{off();resolve(s)},e=>{off();reject(e)})});
  for(const d of snap.docs) await updateDoc(d.ref,{status:"REJECTED",rejectedAt:serverTimestamp()});
  toast("Rejected — balance refunded");
 }catch(e){alert("Reject failed: "+e.message)}
}
window.approveServiceRequest=approveServiceRequest;window.rejectServiceRequest=rejectServiceRequest;

async function approveTx(id){
 const t=cache.transactions.find(x=>x.id===id); if(!t||t.status!=="Pending")return;
 try{
  await runTransaction(db,async tx=>{
   const tr=doc(db,"transactions",id); const snap=await tx.get(tr);
   if(!snap.exists()||snap.data().status!=="Pending")throw new Error("Already processed");
   if(t.type==="Add Money"&&t.userId){
    const ur=doc(db,"users",t.userId), us=await tx.get(ur);
    if(us.exists()){const u=us.data(); tx.update(ur,{mainBalance:Number(u.mainBalance||0)+Number(t.amount||0)});}
   }
   tx.update(tr,{status:"Approved",approvedAt:serverTimestamp()});
  }); toast("Transaction Confirm হয়েছে")
 }catch(e){alert("Confirm failed: "+e.message)}
}
async function rejectTx(id){try{await updateDoc(doc(db,"transactions",id),{status:"Rejected",rejectedAt:serverTimestamp()});toast("Rejected")}catch(e){alert(e.message)}}

function openModal(html){
 const m=document.createElement("div");m.className="modal";m.innerHTML=`<div class="modal-card">${html}</div>`;document.body.appendChild(m);return m;
}
async function viewUser(id){
 const u=cache.users.find(x=>x.id===id);if(!u)return;
 const txs=cache.transactions.filter(t=>t.userId===u.id).slice(0,100);
 const m=openModal(`<div class="panel-head"><h3>👤 ${esc(u.name||"User")} — Full Profile</h3><button class="secondary" id="closeM">Close</button></div>
 <div class="profile-grid"><div><b>User ID</b><p>${esc(u.id)}</p></div><div><b>Phone</b><p>${esc(u.phone||"")}</p></div><div><b>Main Balance</b><p>${money(u.mainBalance)} ${(u.mainLocked||u.mainBalanceLocked)?"🔒 Locked":""}</p></div><div><b>Drive Balance</b><p>${money(u.driveBalance)} ${(u.driveLocked||u.driveBalanceLocked)?"🔒 Locked":""}</p></div></div>
 <div class="notice">Locked balance দেখা যাবে, কিন্তু transaction-এর জন্য ব্যবহার করা যাবে না। Android/backend-এও একই lock rule enforce করতে হবে।</div>
 <h4>Balance / Account Control</h4><div class="grid">${field("uName","নাম",u.name||"")}${field("uPhone","ফোন",u.phone||"")}${field("uMain","Main Balance",u.mainBalance||0)}${field("uDrive","Drive Balance",u.driveBalance||0)}
 <div class="field"><label><input type="checkbox" id="uMainLock" ${(u.mainLocked||u.mainBalanceLocked)?"checked":""}> Main Balance Lock</label></div><div class="field"><label><input type="checkbox" id="uDriveLock" ${(u.driveLocked||u.driveBalanceLocked)?"checked":""}> Drive Balance Lock</label></div><div class="field"><label><input type="checkbox" id="uActive" ${u.active!==false?"checked":""}> Account Active</label></div></div>
 <div class="actions"><button class="primary" id="saveUser">Save Control</button><button class="danger" id="blockUser">${u.active===false?"Account Unblock":"Account Block"}</button></div>
 <h4>Transaction History</h4><div class="table-wrap"><table class="table"><thead><tr><th>Type</th><th>Details</th><th>Amount</th><th>Status</th></tr></thead><tbody>${txs.map(t=>`<tr><td>${esc(t.type)}</td><td>${esc(t.details||"")}</td><td>${t.in?"+":"-"}${money(t.amount)}</td><td>${esc(t.status||"")}</td></tr>`).join("")||'<tr><td colspan="4">কোনো transaction নেই।</td></tr>'}</tbody></table></div>`);
 m.querySelector("#closeM").onclick=()=>m.remove();
 m.querySelector("#saveUser").onclick=async()=>{try{await updateDoc(doc(db,"users",u.id),{name:$("uName").value,phone:$("uPhone").value,mainBalance:Math.max(0,Number($("uMain").value||0)),driveBalance:Math.max(0,Number($("uDrive").value||0)),mainLocked:$("uMainLock").checked,driveLocked:$("uDriveLock").checked,mainBalanceLocked:$("uMainLock").checked,driveBalanceLocked:$("uDriveLock").checked,accountLocked:!$("uActive").checked,status:$("uActive").checked?"ACTIVE":"BLOCKED",active:$("uActive").checked,updatedAt:serverTimestamp()});m.remove();toast("User updated")}catch(e){alert(e.message)}};
 m.querySelector("#blockUser").onclick=async()=>{try{await updateDoc(doc(db,"users",u.id),{active:u.active===false,accountLocked:u.active!==false,status:u.active===false?"ACTIVE":"BLOCKED",updatedAt:serverTimestamp()});m.remove();toast("Account status updated")}catch(e){alert(e.message)}};
}
async function addUser(){const name=prompt("User name");if(!name)return;const phone=prompt("Phone");if(!phone)return;try{await addDoc(col("users"),{name,phone,mainBalance:0,driveBalance:0,active:true,mainLocked:false,driveLocked:false,createdAt:serverTimestamp()});toast("User added")}catch(e){alert(e.message)}}

function openOffer(id=null){
 const o=id?cache.offers.find(x=>x.id===id):{operator:selectedOperator,offer_name:"",data:"",minutes:"",sms:"",price:"",bonus:"",validity:"",description:"",logo:"",active:true};
 const m=openModal(`<h3>${id?"Edit":"Add"} Offer</h3><div class="grid"><div class="field"><label>Operator</label><select id="fop">${ops.map(x=>`<option ${x===o.operator?"selected":""}>${x}</option>`).join("")}</select></div>${field("fon","Offer Name",o.offer_name||"")}${field("fdata","Data / GB",o.data||"")}${field("fmin","Minutes",o.minutes||"")}${field("fsms","SMS",o.sms||"")}${field("fprice","Price",o.price||"")}${field("fbonus","Bonus",o.bonus||"")}${field("fvalid","Validity",o.validity||"")}${field("flogo","Logo / Image URL",o.logo||"")}<div class="field full"><label>Description</label><textarea id="fdesc">${esc(o.description||"")}</textarea></div><div class="field"><label><input id="fact" type="checkbox" ${o.active!==false?"checked":""}> Active</label></div></div><div class="actions"><button class="secondary" id="closeM">Cancel</button><button class="primary" id="saveM">Save Offer</button></div>`);
 m.querySelector("#closeM").onclick=()=>m.remove();
 m.querySelector("#saveM").onclick=async()=>{const n={operator:$("fop").value,offer_name:$("fon").value,data:$("fdata").value,minutes:$("fmin").value,sms:$("fsms").value,price:Number($("fprice").value||0),bonus:Number($("fbonus").value||0),validity:$("fvalid").value,description:$("fdesc").value,logo:$("flogo").value,active:$("fact").checked,updatedAt:serverTimestamp()};try{id?await updateDoc(doc(db,"offers",id),n):await addDoc(col("offers"),{...n,createdAt:serverTimestamp()});m.remove();toast("Offer saved")}catch(e){alert(e.message)}}
}
window.editOffer=openOffer;
window.deleteOffer=async id=>{if(confirm("Delete this offer?"))await deleteDoc(doc(db,"offers",id))};

function renderLivePreview(){
  const items=cache.live.filter(x=>x.active!==false);
  if(!items.length) return `<div class="empty">Preview দেখানোর জন্য Active Activity যোগ করুন।</div>`;
  const x=items[0];
  return `<div class="live-preview-card"><span class="live-dot">● LIVE</span><b>${esc(x.name||"User")}</b><span>${esc(x.phone||"")}</span><strong>${money(x.amount||0)}</strong><span>${esc(x.type||"")}</span></div>`;
}

function liveModal(existing={}){
  const m=openModal(`<h3>${existing.id?"Edit":"Add"} Live Activity</h3>
  <div class="notice">এই Activity শুধু প্রদর্শনের জন্য। কোনো আসল টাকা কাটা/যোগ হবে না। সর্বোচ্চ ৫০০টি Activity রাখা যাবে।</div>
  <div class="grid">
    ${field("lname","Name",existing.name||"")}
    ${field("lphone","Mobile Number",existing.phone||"")}
    ${field("lamount","Amount",existing.amount||"")}
    <div class="field"><label>Transaction Type</label>
      <select id="ltype">
        ${["Cash In","Send Money","Receive Money","Cash Out","Bank Transfer","Mobile Recharge"].map(t=>`<option ${t===(existing.type||"Cash In")?"selected":""}>${t}</option>`).join("")}
      </select>
    </div>
    ${field("ltime","Display Time",existing.displayTime||"")}
    <div class="field"><label><input id="lactive" type="checkbox" ${existing.active!==false?"checked":""}> Active</label></div>
    <div class="field full"><label>Custom Activity Text</label><textarea id="ltext" placeholder="যেমন: Rahim 01712****45 থেকে ৳500 Cash In করেছে">${esc(existing.text||"")}</textarea></div>
  </div>
  <div class="actions"><button class="secondary" id="closeLiveM">Cancel</button><button class="primary" id="saveLiveM">Save Activity</button></div>`);
  m.querySelector("#closeLiveM").onclick=()=>m.remove();
  m.querySelector("#saveLiveM").onclick=async()=>{
    if(cache.live.length>=500 && !existing.id){alert("সর্বোচ্চ ৫০০টি Live Activity রাখা যাবে।");return}
    const name=$("lname").value.trim();
    const phone=$("lphone").value.trim();
    const amount=Number($("lamount").value||0);
    const type=$("ltype").value;
    const displayTime=$("ltime").value.trim() || nowText();
    const text=$("ltext").value.trim() || `${name||"User"} ${phone?phone+" ":""}থেকে ${money(amount)} ${type} করেছে`;
    const data={name,phone,amount,type,displayTime,text,active:$("lactive").checked,updatedAt:serverTimestamp()};
    try{
      if(existing.id) await updateDoc(doc(db,"liveActivities",existing.id),data);
      else await addDoc(col("liveActivities"),{...data,createdAt:serverTimestamp()});
      m.remove(); toast("Live Activity saved");
    }catch(e){alert(e.message)}
  };
}

async function addLive(){
  if(cache.live.length>=500){alert("সর্বোচ্চ ৫০০টি Live Activity রাখা যাবে।");return}
  liveModal({});
}
window.editLive=async id=>{
  const x=cache.live.find(v=>v.id===id);
  if(x) liveModal(x);
};
window.toggleLive=async(id,v)=>updateDoc(doc(db,"liveActivities",id),{active:!v,updatedAt:serverTimestamp()});
window.delLive=async id=>{if(confirm("এই Live Activity delete করবেন?"))await deleteDoc(doc(db,"liveActivities",id))};

async function saveLiveSettings(){
  const seconds=Math.max(3,Math.min(60,Number($("liveInterval").value||5)));
  const enabled=$("liveEnabled").value==="true";
  await setDoc(doc(db,"settings","general"),{
    liveRotateSeconds:seconds,
    liveEnabled:enabled,
    liveMaxItems:500,
    updatedAt:serverTimestamp()
  },{merge:true});
  toast("Live settings saved");
};

async function savePaymentNumbers(){
  try{
    const paymentNumbers = {
      bkashNumber:$("bkashNumber").value.trim(),
      nagadNumber:$("nagadNumber").value.trim(),
      rocketNumber:$("rocketNumber").value.trim(),
      bkashVisible:$("bkashVisible").checked,
      nagadVisible:$("nagadVisible").checked,
      rocketVisible:$("rocketVisible").checked,
      updatedAt:serverTimestamp()
    };

    // Keep the existing admin settings document unchanged for the panel,
    // and also publish only the three payment numbers to a public app document.
    await setDoc(doc(db,"settings","general"),paymentNumbers,{merge:true});
    await setDoc(doc(db,"publicSettings","paymentNumbers"),paymentNumbers,{merge:true});

    toast("Payment Numbers saved");
  }catch(e){alert("Save failed: "+e.message)}
}
async function saveBanner(){await setDoc(doc(db,"settings","general"),{bannerImage:$("bannerImage").value,bannerLink:$("bannerLink").value,bannerActive:$("bannerActive").checked},{merge:true});toast("Banner saved")}
async function saveInvite(){await setDoc(doc(db,"settings","general"),{inviteAmount:$("inviteAmount").value,inviteRules:$("inviteRules").value,inviteActive:$("inviteEnabled").checked},{merge:true});toast("Invite settings saved")}
async function saveCare(){await setDoc(doc(db,"settings","general"),{careWhatsapp:$("careWhatsapp").value},{merge:true});toast("Customer Care saved")}
async function saveAbout(){await setDoc(doc(db,"settings","general"),{aboutName:$("aboutName").value,aboutLicense:$("aboutLicense").value,aboutAddress:$("aboutAddress").value,aboutPhone:$("aboutPhone").value,aboutIntro:$("aboutIntro").value,aboutDetails:$("aboutDetails").value},{merge:true});toast("About Us saved")}

async function addMedia(type){const title=prompt("Title");if(!title)return;const url=prompt("URL");if(!url)return;await addDoc(col(type),{title,url,active:true,createdAt:serverTimestamp()})}
window.addMedia=addMedia;
window.toggleMedia=async(type,id,v)=>updateDoc(doc(db,type,id),{active:!v});
window.deleteMedia=async(type,id)=>{if(confirm("Delete?"))await deleteDoc(doc(db,type,id))};

window.approveChat=async id=>{try{await updateDoc(doc(db,"chatMessages",id),{status:"Approved",approvedAt:serverTimestamp()});toast("Chat approved")}catch(e){alert(e.message)}};
window.rejectChat=async id=>{try{await updateDoc(doc(db,"chatMessages",id),{status:"Rejected",rejectedAt:serverTimestamp()});toast("Chat rejected")}catch(e){alert(e.message)}};
window.approveTx=approveTx;window.rejectTx=rejectTx;window.viewUser=viewUser;
