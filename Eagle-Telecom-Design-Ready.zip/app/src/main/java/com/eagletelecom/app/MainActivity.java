package com.eagletelecom.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.content.*;
import android.widget.Toast;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(5,92,61));
        getWindow().setNavigationBarColor(Color.WHITE);
        setContentView(new EagleHomeView(this));
    }

    static class EagleHomeView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        float d;
        boolean balanceVisible = true;
        int green = Color.rgb(5,105,70), green2 = Color.rgb(7,92,61);
        int blue = Color.rgb(18,128,219), yellow = Color.rgb(255,202,0);
        int dark = Color.rgb(40,40,40);
        RectF r = new RectF();
        String[] icons = {"💼","📱","🏦","⚡","👥","🎁","🧾","🏷️","🎧","⭐","▶","❓"};
        String[] labels = {"ব্যালেন্স\nরিচার্জ","মোবাইল\nরিচার্জ","ব্যাংক\nট্রান্সফার","মোবাইল\nউপায়ন",
                           "গ্রুপ\nচ্যাট","ট্রাইভ\nঅফার","বিল\nপে","বিশেষ\nঅফার",
                           "কাস্টমার\nকেয়ার","কাস্টমার\nরিভিউ","ভিডিও\nটিউটোরিয়াল","আমাদের\nসম্পর্কে"};
        String[] actions = {"ব্যালেন্স রিচার্জ","মোবাইল রিচার্জ","ব্যাংক ট্রান্সফার","মোবাইল উপায়ন",
                            "গ্রুপ চ্যাট","ট্রাইভ অফার","বিল পে","বিশেষ অফার","কাস্টমার কেয়ার",
                            "কাস্টমার রিভিউ","ভিডিও টিউটোরিয়াল","আমাদের সম্পর্কে"};
        RectF[] boxes = new RectF[12];

        EagleHomeView(Context c){ super(c); d=getResources().getDisplayMetrics().density; stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(2*d); setLayerType(View.LAYER_TYPE_SOFTWARE,null); }

        float dp(float v){return v*d;}
        void txt(Canvas c,String s,float x,float y,float size,int color,Paint.Align align){
            p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextSize(dp(size)); p.setTextAlign(align); p.setTypeface(Typeface.create("sans",Typeface.NORMAL)); c.drawText(s,x,y,p);
        }
        void bold(Canvas c,String s,float x,float y,float size,int color,Paint.Align align){
            p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextSize(dp(size)); p.setTextAlign(align); p.setTypeface(Typeface.create("sans",Typeface.BOLD)); c.drawText(s,x,y,p);
        }
        void round(Canvas c,float l,float t,float rr,float bb,float rad,int color){
            p.setStyle(Paint.Style.FILL); p.setColor(color); p.setShadowLayer(dp(4),0,dp(2),0x22000000);
            r.set(l,t,rr,bb); c.drawRoundRect(r,dp(rad),dp(rad),p); p.clearShadowLayer();
        }
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            float w=getWidth(), h=getHeight();
            c.drawColor(Color.rgb(246,247,247));

            // Header
            p.setColor(green); p.setStyle(Paint.Style.FILL);
            c.drawRect(0,0,w,dp(285),p);
            txt(c,"🦅",dp(26),dp(70),42,Color.WHITE,Paint.Align.LEFT);
            bold(c,"Eagle Telecom",dp(86),dp(61),27,Color.WHITE,Paint.Align.LEFT);
            txt(c,"দ্রুত সেবা, আপনার পাশে",dp(88),dp(88),14,0xFFE8FFF3,Paint.Align.LEFT);
            bold(c,"EN",w-dp(140),dp(67),17,Color.WHITE,Paint.Align.CENTER);
            txt(c,"♧",w-dp(82),dp(68),33,Color.WHITE,Paint.Align.CENTER);
            txt(c,"⇥",w-dp(30),dp(68),35,Color.WHITE,Paint.Align.CENTER);

            // User + referral
            txt(c,"👤",dp(32),dp(153),40,Color.WHITE,Paint.Align.LEFT);
            bold(c,"Rosy",dp(92),dp(148),24,Color.WHITE,Paint.Align.LEFT);
            txt(c,"016********",dp(92),dp(174),14,0xFFE7FFF4,Paint.Align.LEFT);
            round(c,w-dp(350),dp(120),w-dp(20),dp(176),28,yellow);
            bold(c,"রেফারেল কোড: 123456",w-dp(190),dp(156),15,Color.DKGRAY,Paint.Align.CENTER);
            txt(c,"⧉",w-dp(44),dp(158),22,Color.DKGRAY,Paint.Align.CENTER);

            // Balance card
            round(c,dp(28),dp(205),w-dp(28),dp(350),25,blue);
            txt(c,"মেইন ব্যালেন্স",dp(72),dp(258),17,Color.WHITE,Paint.Align.LEFT);
            bold(c,balanceVisible?"৳ 1250.00":"৳ ••••••",dp(72),dp(316),37,Color.WHITE,Paint.Align.LEFT);
            round(c,w-dp(190),dp(263),w-dp(45),dp(318),28,Color.WHITE);
            txt(c,balanceVisible?"◉":"◎",w-dp(158),dp(298),22,blue,Paint.Align.CENTER);
            bold(c,balanceVisible?"ব্যালেন্স লুকান":"ব্যালেন্স দেখুন",w-dp(112),dp(298),13,blue,Paint.Align.CENTER);

            // Notice
            round(c,dp(28),dp(365),w-dp(28),dp(418),18,0xFFE9F7FF);
            txt(c,"●",dp(52),dp(398),18,0xFF1EBD68,Paint.Align.CENTER);
            bold(c,"সর্বশেষ আপডেট: আজ রাত ১২টা পর্যন্ত সকল সিমে ৫% বোনাস রিচার্জ অফার!",dp(78),dp(399),14,dark,Paint.Align.LEFT);

            // Service cards
            float top=dp(440), gap=dp(18), cardH=dp(170), left=dp(24), right=w-dp(24);
            int idx=0;
            for(int row=0;row<3;row++){
                round(c,left,top+row*(cardH+gap),right,top+row*(cardH+gap)+cardH,22,Color.WHITE);
                float cw=(right-left)/4f;
                for(int col=0;col<4;col++){
                    float cx=left+cw*(col+.5f);
                    float cy=top+row*(cardH+gap)+dp(61);
                    if(idx<12){
                        p.setColor(0xFFF2F7FA); p.setStyle(Paint.Style.FILL);
                        c.drawCircle(cx,cy,dp(42),p);
                        txt(c,icons[idx],cx,cy+dp(14),37,Color.DKGRAY,Paint.Align.CENTER);
                        String[] ls=labels[idx].split("\\n");
                        for(int k=0;k<ls.length;k++) txt(c,ls[k],cx,top+row*(cardH+gap)+dp(116+k*23),15,dark,Paint.Align.CENTER);
                        boxes[idx]=new RectF(cx-cw/2,top+row*(cardH+gap),cx+cw/2,top+row*(cardH+gap)+cardH);
                        idx++;
                    }
                }
            }

            // Banner
            float by=top+3*(cardH+gap);
            round(c,left,by,right,by+dp(118),20,0xFF0569A9);
            txt(c,"🎁",left+dp(55),by+dp(75),50,Color.WHITE,Paint.Align.CENTER);
            bold(c,"রিচার্জ করলেই পাবেন",w/2,by+dp(40),17,Color.WHITE,Paint.Align.CENTER);
            bold(c,"বিশেষ বোনাস",w/2,by+dp(79),31,Color.YELLOW,Paint.Align.CENTER);
            txt(c,"দ্রুত রিচার্জ করুন, বেশি বোনাস নিন",w/2,by+dp(104),13,Color.WHITE,Paint.Align.CENTER);

            // Bottom nav
            float navTop=h-dp(88);
            p.setColor(Color.WHITE); p.setStyle(Paint.Style.FILL); c.drawRect(0,navTop,w,h,p);
            txt(c,"⌂",w*.17f,navTop+dp(39),34,0xFFDA4040,Paint.Align.CENTER);
            bold(c,"হোম",w*.17f,navTop+dp(67),13,0xFFDA4040,Paint.Align.CENTER);
            txt(c,"◷",w*.50f,navTop+dp(42),33,0xFF9E9E9E,Paint.Align.CENTER);
            txt(c,"লেনদেন",w*.50f,navTop+dp(67),13,0xFF888888,Paint.Align.CENTER);
            txt(c,"♙",w*.83f,navTop+dp(41),35,0xFF9E9E9E,Paint.Align.CENTER);
            txt(c,"প্রোফাইল",w*.83f,navTop+dp(67),13,0xFF888888,Paint.Align.CENTER);
        }

        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_UP) return true;
            float x=e.getX(), y=e.getY(), w=getWidth(), h=getHeight();
            if(y>dp(250) && y<dp(335) && x>w-dp(220)){
                balanceVisible=!balanceVisible; invalidate(); return true;
            }
            float top=dp(440), gap=dp(18), cardH=dp(170), left=dp(24), right=w-dp(24), cw=(right-left)/4f;
            for(int i=0;i<12;i++){
                if(boxes[i]!=null && boxes[i].contains(x,y)){
                    Toast.makeText(getContext(), actions[i]+" — Demo", Toast.LENGTH_SHORT).show();
                    return true;
                }
            }
            if(y>h-dp(90)){
                if(x<w/3) Toast.makeText(getContext(),"হোম",Toast.LENGTH_SHORT).show();
                else if(x<2*w/3) Toast.makeText(getContext(),"লেনদেন",Toast.LENGTH_SHORT).show();
                else Toast.makeText(getContext(),"প্রোফাইল",Toast.LENGTH_SHORT).show();
            }
            return true;
        }
    }
}
