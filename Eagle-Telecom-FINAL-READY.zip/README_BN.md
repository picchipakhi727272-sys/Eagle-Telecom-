# Eagle Telecom

এই project-টি reference screenshot-এর মতো সবুজ header, হলুদ wallet pill, 4-column service cards, offer banner এবং bottom navigation সহ তৈরি করা হয়েছে।

## Build
GitHub Actions → Build Eagle Telecom APK → Run workflow.
Artifact: `Eagle-Telecom-debug-apk`

## API
bKash/Nagad/Bank/Recharge-এর real credentials এখানে রাখা হয়নি। পরে নিরাপদ backend/API endpoint বসাতে হবে। APK-এর ভিতরে secret রাখা উচিত নয়।
