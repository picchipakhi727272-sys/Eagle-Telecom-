package com.eagletelecom.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.content.*;
import java.util.*;

public class MainActivity extends Activity {

    EagleView view;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(11,107,71));
        getWindow().setNavigationBarColor(Color.BLACK);
        view = new EagleView(this);
        setContentView(view);
    }

    @Override public void onBackPressed() {
        if (!view.screen.equals("home")) {
            view.screen = "home";
            view.invalidate();
        } else super.onBackPressed();
    }

    static class EagleView extends View {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        String screen = "home";
        boolean balanceVisible = true;
        int green = Color.rgb(11,107,71);
        int darkGreen = Color.rgb(5,93,61);
        int yellow = Color.rgb(255,205,0);
        int bg = Color.rgb(246,247,249);
        int red = Color.rgb(216,70,70);
        float den;
        ArrayList<String[]> services = new ArrayList<>();

        EagleView(Context c) {
            super(c);
            den = getResources().getDisplayMetrics().density;
            p.setTypeface(Typeface.create("sans", Typeface.NORMAL));
            services.add(new String[]{"▣","ওয়ালেট","ডিপোজিট","deposit"});
            services.add(new String[]{"▤","মোবাইল","ব্যাংকিং","mobile"});
            services.add(new String[]{"⌂","ব্যাংক","ট্রান্সফার","bank"});
            services.add(new String[]{"▥","মোবাইল","টপআপ","topup"});
            services.add(new String[]{"☷","গ্রুপ","চ্যাট","chat"});
            services.add(new String[]{"🎁","ডাইরেক্ট","অফার","offer"});
            services.add(new String[]{"▤","বিল","পে","bill"});
            services.add(new String[]{"%","বিশেষ","অফার","special"});
            services.add(new String[]{"♧","কাস্টমার","কেয়ার","care"});
            services.add(new String[]{"★","কাস্টমার","রিভিউ","review"});
            services.add(new String[]{"▶","ভিডিও","টিউটোরিয়াল","video"});
            services.add(new String[]{"?","আমাদের","সম্পর্কে","about"});
        }

        float d(float x){ return x*den; }

        void fill(int color){ p.setStyle(Paint.Style.FILL); p.setColor(color); }
        void text(Canvas c,String s,float x,float y,float size,int color,Paint.Align a){
            p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextSize(d(size)); p.setTextAlign(a);
            p.setTypeface(Typeface.create("sans", Typeface.NORMAL)); c.drawText(s,d(x),d(y),p);
        }
        void bold(Canvas c,String s,float x,float y,float size,int color,Paint.Align a){
            p.setStyle(Paint.Style.FILL); p.setColor(color); p.setTextSize(d(size)); p.setTextAlign(a);
            p.setTypeface(Typeface.create("sans", Typeface.BOLD)); c.drawText(s,d(x),d(y),p);
        }
        void round(Canvas c,float l,float t,float r,float b,float rad,int color){
            fill(color); c.drawRoundRect(d(l),d(t),d(r),d(b),d(rad),d(rad),p);
        }
        void line(Canvas c,float x1,float y1,float x2,float y2,int color,float w){
            p.setColor(color); p.setStrokeWidth(d(w)); p.setStyle(Paint.Style.STROKE);
            c.drawLine(d(x1),d(y1),d(x2),d(y2),p);
        }

        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            c.drawColor(bg);
            if(screen.equals("home")) drawHome(c);
            else drawInner(c);
        }

        void drawHeader(Canvas c){
            // Green rounded top block
            round(c,0,0,360,205,0,green);
            round(c,0,160,360,205,0,green);
            // logo box
            round(c,15,18,112,73,16,Color.WHITE);
            bold(c,"🦅",38,52,25,Color.rgb(15,65,120),Paint.Align.CENTER);
            bold(c,"Eagle",73,43,12,Color.rgb(15,65,120),Paint.Align.CENTER);
            bold(c,"Telecom",73,58,10,green,Paint.Align.CENTER);
            // top actions
            bold(c,"EN",244,49,15,Color.WHITE,Paint.Align.CENTER);
            text(c,"♧",283,52,31,Color.WHITE,Paint.Align.CENTER);
            text(c,"↪",326,52,30,Color.WHITE,Paint.Align.CENTER);
            // user + balance
            bold(c,"Rosy",15,110,24,Color.WHITE,Paint.Align.LEFT);
            round(c,107,91,345,132,28,yellow);
            text(c,balanceVisible ? "মেইন ব্যালেন্স:  • • • •  / ট্রেড ব্যালেন্স:  • • • •" : "মেইন ব্যালেন্স:  ৳ 1250.00",218,117,11,Color.DKGRAY,Paint.Align.CENTER);
            text(c,balanceVisible ? "◉" : "◉",328,118,20,Color.DKGRAY,Paint.Align.CENTER);
            // notification
            round(c,14,145,346,198,18,Color.WHITE);
            fill(Color.rgb(38,191,98)); c.drawCircle(d(31),d(171),d(7),p);
            text(c,"রাকিব রহমান (016********) ৭৯৯ টাকা এয়ারটেল রিচার্জ করলেন",47,176,11,Color.DKGRAY,Paint.Align.LEFT);
        }

        void drawHome(Canvas c){
            drawHeader(c);
            // cards
            int startY = 216;
            for(int row=0; row<3; row++){
                float top = startY + row*111;
                round(c,11,top,349,top+101,23,Color.WHITE);
                for(int col=0; col<4; col++){
                    int idx=row*4+col;
                    float cx=54 + col*85;
                    String[] s=services.get(idx);
                    // simple colorful icon circle/box
                    int[] iconColors={Color.rgb(247,150,42),Color.rgb(75,137,220),Color.rgb(238,187,42),Color.rgb(64,146,221)};
                    fill(iconColors[idx%4]);
                    c.drawCircle(d(cx),d(top+38),d(19),p);
                    text(c,s[0],cx,top+46,19,Color.WHITE,Paint.Align.CENTER);
                    text(c,s[1],cx,top+68,10,Color.DKGRAY,Paint.Align.CENTER);
                    text(c,s[2],cx,top+84,10,Color.DKGRAY,Paint.Align.CENTER);
                }
            }
            // promotional banner
            round(c,14,555,346,665,17,Color.rgb(18,65,20));
            bold(c,"ডিপোজিট বোনাস অফার",180,584,22,Color.YELLOW,Paint.Align.CENTER);
            text(c,"এখনই করুন, বোনাস নিয়ে নিন!",180,604,11,Color.WHITE,Paint.Align.CENTER);
            round(c,24,616,126,653,10,Color.rgb(9,100,43));
            round(c,132,616,228,653,10,Color.rgb(18,76,146));
            round(c,234,616,336,653,10,Color.rgb(9,100,43));
            bold(c,"১২৯৯ টাকা",75,638,13,Color.WHITE,Paint.Align.CENTER);
            bold(c,"২৫৯৯ টাকা",180,638,13,Color.WHITE,Paint.Align.CENTER);
            bold(c,"৪৫৯৯ টাকা",285,638,13,Color.WHITE,Paint.Align.CENTER);
            // bottom nav
            fill(Color.WHITE); c.drawRect(0,d(675),getWidth(),getHeight(),p);
            text(c,"⌂",60,710,32,red,Paint.Align.CENTER);
            text(c,"◷",180,710,31,Color.LTGRAY,Paint.Align.CENTER);
            text(c,"♙",300,710,32,Color.LTGRAY,Paint.Align.CENTER);
            bold(c,"হোম",60,738,11,red,Paint.Align.CENTER);
            text(c,"লেনদেন",180,738,11,Color.GRAY,Paint.Align.CENTER);
            text(c,"প্রোফাইল",300,738,11,Color.GRAY,Paint.Align.CENTER);
        }

        void drawInner(Canvas c){
            fill(green); c.drawRect(0,0,getWidth(),d(78),p);
            text(c,"‹",24,52,38,Color.WHITE,Paint.Align.CENTER);
            bold(c, titleFor(screen),52,49,20,Color.WHITE,Paint.Align.LEFT);
            // content card
            round(c,15,100,345,570,22,Color.WHITE);
            text(c,iconFor(screen),180,160,54,green,Paint.Align.CENTER);
            bold(c,titleFor(screen),180,205,24,Color.DKGRAY,Paint.Align.CENTER);
            text(c,descriptionFor(screen),180,245,13,Color.GRAY,Paint.Align.CENTER);
            // generic form/actions
            if(screen.equals("topup") || screen.equals("mobile") || screen.equals("bank") || screen.equals("deposit") || screen.equals("bill")){
                field(c,"মোবাইল / অ্যাকাউন্ট নম্বর",130);
                field(c,"টাকার পরিমাণ",190);
                field(c,"নোট / রেফারেন্স (ঐচ্ছিক)",250);
                round(c,65,325,295,375,25,green);
                bold(c,"পরবর্তী",180,357,17,Color.WHITE,Paint.Align.CENTER);
            } else if(screen.equals("chat")){
                field(c,"আপনার মেসেজ লিখুন",130);
                round(c,65,205,295,255,25,green);
                bold(c,"মেসেজ পাঠান",180,237,17,Color.WHITE,Paint.Align.CENTER);
            } else if(screen.equals("review")){
                text(c,"★★★★★",180,300,35,Color.rgb(245,190,25),Paint.Align.CENTER);
                field(c,"আপনার মতামত লিখুন",350);
                round(c,65,425,295,475,25,green);
                bold(c,"রিভিউ দিন",180,457,17,Color.WHITE,Paint.Align.CENTER);
            } else {
                round(c,65,330,295,380,25,green);
                bold(c,screen.equals("care")?"কাস্টমার কেয়ারে যোগাযোগ":"বিস্তারিত দেখুন",180,362,16,Color.WHITE,Paint.Align.CENTER);
            }
        }

        void field(Canvas c,String s,float y){
            round(c,35,y,325,y+48,13,Color.rgb(246,247,249));
            text(c,s,55,y+31,13,Color.GRAY,Paint.Align.LEFT);
        }
        String titleFor(String s){
            for(String[] a:services) if(a[3].equals(s)) return a[1]+" "+a[2];
            if(s.equals("transactions")) return "লেনদেন";
            if(s.equals("profile")) return "প্রোফাইল";
            return "Eagle Telecom";
        }
        String iconFor(String s){
            if(s.equals("deposit")) return "＋";
            if(s.equals("mobile")) return "▣";
            if(s.equals("bank")) return "⌂";
            if(s.equals("topup")) return "▥";
            if(s.equals("chat")) return "☷";
            if(s.equals("offer")||s.equals("special")) return "🎁";
            if(s.equals("bill")) return "▤";
            if(s.equals("care")) return "♧";
            if(s.equals("review")) return "★";
            if(s.equals("video")) return "▶";
            if(s.equals("about")) return "ⓘ";
            return "•";
        }
        String descriptionFor(String s){
            if(s.equals("deposit")) return "ওয়ালেটে টাকা যোগ করার জন্য তথ্য দিন";
            if(s.equals("mobile")) return "মোবাইল ব্যাংকিং-এর মাধ্যমে লেনদেন";
            if(s.equals("bank")) return "ব্যাংক অ্যাকাউন্টে টাকা ট্রান্সফার";
            if(s.equals("topup")) return "মোবাইল নম্বর ও টাকার পরিমাণ দিয়ে রিচার্জ";
            if(s.equals("chat")) return "গ্রুপের সদস্যদের সাথে যোগাযোগ করুন";
            if(s.equals("offer")||s.equals("special")) return "আপনার জন্য বর্তমান অফারগুলো";
            if(s.equals("bill")) return "বিভিন্ন বিল পরিশোধের সুবিধা";
            if(s.equals("care")) return "সহায়তার জন্য আমাদের সাথে যোগাযোগ করুন";
            if(s.equals("review")) return "আপনার অভিজ্ঞতা আমাদের জানান";
            if(s.equals("video")) return "অ্যাপ ব্যবহারের ভিডিও নির্দেশিকা";
            if(s.equals("about")) return "Eagle Telecom সম্পর্কে তথ্য";
            return "";
        }

        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            if(e.getAction()!=MotionEvent.ACTION_UP) return true;
            float x=e.getX()/den, y=e.getY()/den;

            if(screen.equals("home")){
                // top eye/balance
                if(y>85 && y<140 && x>100){ balanceVisible=!balanceVisible; invalidate(); return true; }
                // service grid
                int row=(int)((y-216)/111);
                if(row>=0 && row<3){
                    int col=(int)((x-12)/85);
                    if(col>=0 && col<4){
                        int idx=row*4+col;
                        if(idx<services.size()){ screen=services.get(idx)[3]; invalidate(); return true; }
                    }
                }
                // bottom nav
                if(y>675){
                    if(x<120){screen="home"; invalidate();}
                    else if(x<240){screen="transactions"; invalidate();}
                    else {screen="profile"; invalidate();}
                }
            } else {
                if(y<80 && x<70){ screen="home"; invalidate(); }
            }
            return true;
        }
    }
}
