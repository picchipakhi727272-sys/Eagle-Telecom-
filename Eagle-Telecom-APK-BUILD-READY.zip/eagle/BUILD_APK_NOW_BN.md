# Eagle Telecom APK — একদম সহজে APK বানানো

এই project-এ `.github/workflows/gradle.yml` আগে থেকেই আছে। GitHub Actions নিজে Gradle + JDK সেট করে debug APK বানাবে।

## ফোন থেকে
1. GitHub-এ নতুন repository বানাও।
2. এই ZIP-এর **সব ফাইল** repository-তে upload করো (ZIP ফাইলটা নয়, ZIP খুলে ভেতরের ফাইলগুলো)।
3. `main` branch-এ ফাইলগুলো রাখো।
4. GitHub → **Actions** → **Build Eagle Telecom APK** → **Run workflow** চাপো।
5. Build শেষ হলে workflow-এর **Artifacts** থেকে `Eagle-Telecom-debug-apk` download করো।
6. ZIP খুলে `app-debug.apk` ফোনে install করো।

এটা UI/demo APK। আসল টাকা, bKash/Nagad, ব্যাংক বা রিচার্জ চালাতে secure backend ও বৈধ provider API লাগবে।
