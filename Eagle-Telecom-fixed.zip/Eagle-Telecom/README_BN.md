# Eagle Telecom Android Project

এটি Eagle Telecom-এর Android demo/MVP source project। Project structure ও GitHub Actions build configuration ঠিক করা হয়েছে।

### ফিচার
- Login / Registration
- Home dashboard ও wallet balance demo
- Mobile Recharge
- Add Money / Send Money / Bank Transfer / Bill Pay screens
- Offers / Transactions / Profile / Customer Care
- Admin Panel demo

### গুরুত্বপূর্ণ
এখানে কোনো আসল bKash/Nagad/Bank বা recharge API নেই। বাস্তব টাকা বা রিচার্জ চালু করতে বৈধ merchant/API credentials, secure backend, database, OTP/authentication ইত্যাদি যুক্ত করতে হবে।

### Build
GitHub Actions workflow Gradle 8.2.1 এবং JDK 17 দিয়ে `gradle assembleDebug` চালাবে। ফলে আলাদা `gradlew` wrapper-এর প্রয়োজন হবে না।
