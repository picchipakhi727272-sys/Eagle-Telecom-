package com.eagletelecom.app;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.content.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    FrameLayout root;
    final int GREEN=Color.rgb(5,105,70), DARK_GREEN=Color.rgb(5,92,61), YELLOW=Color.rgb(255,202,0), BG=Color.rgb(246,247,247), RED=Color.rgb(216,62,62), BLUE=Color.rgb(22,126,216);
    boolean balanceVisible=true;
    String currentScreen="home";

    String[] icons={"💼","📱","🏦","⚡","👥","🎁","🧾","🏷️","🎧","⭐","▶️","❓"};
    String[] labels={"ওয়ালেট\nডিপোজিট","মোবাইল\nব্যাংকিং","ব্যাংক\nট্রান্সফার","মোবাইল\nটপআপ","গ্রুপ\nচ্যাট","ডাইরেক্ট\nঅফার","বিল\nপে","বিশেষ\nঅফার","কাস্টমার\nকেয়ার","কাস্টমার\nরিভিউ","ভিডিও\nটিউটোরিয়াল","আমাদের\nসম্পর্কে"};

    @Override public void onCreate(Bundle b){ super.onCreate(b); getWindow().setStatusBarColor(DARK_GREEN); getWindow().setNavigationBarColor(Color.WHITE); showHome(); }

    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    TextView tv(String text,float sp,int color,boolean bold){ TextView t=new TextView(this); t.setText(text); t.setTextSize(sp); t.setTextColor(color); t.setGravity(Gravity.CENTER_VERTICAL); t.setFontFeatureSettings("kern"); if(bold)t.setTypeface(android.graphics.Typeface.DEFAULT,1); return t; }
    GradientDrawable bg(int color,float radius){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); return g; }
    GradientDrawable strokeBg(int color,int stroke,float radius){ GradientDrawable g=bg(color,radius); g.setStroke(dp(1),stroke); return g; }
    LinearLayout row(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    LinearLayout col(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    void pad(View v,int l,int t,int r,int b){v.setPadding(dp(l),dp(t),dp(r),dp(b));}
    void clear(){ root=new FrameLayout(this); root.setBackgroundColor(BG); setContentView(root); }
    void add(View v,int w,int h){ root.addView(v,new FrameLayout.LayoutParams(dp(w),h==0?FrameLayout.LayoutParams.WRAP_CONTENT:dp(h))); }

    TextView title(String s){ TextView t=tv(s,21,Color.WHITE,true); t.setGravity(Gravity.CENTER); t.setBackgroundColor(GREEN); return t; }
    TextView backHeader(String name){
        LinearLayout h=row(); h.setBackgroundColor(GREEN); h.setPadding(dp(10),0,dp(12),0);
        TextView b=tv("‹",34,Color.WHITE,false); b.setGravity(Gravity.CENTER); h.addView(b,new LinearLayout.LayoutParams(dp(52),dp(64))); b.setOnClickListener(v->showHome());
        TextView n=tv(name,20,Color.WHITE,true); h.addView(n,new LinearLayout.LayoutParams(0,dp(64),1));
        return wrapHeader(h);
    }
    TextView wrapHeader(LinearLayout h){
        TextView dummy=new TextView(this); dummy.setVisibility(View.GONE); // placeholder, header added separately by caller when needed
        return dummy;
    }

    void baseWithHeader(String name){ clear(); LinearLayout page=col(); root.addView(page,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout h=row(); h.setBackgroundColor(GREEN); h.setPadding(dp(8),0,dp(8),0);
        TextView back=tv("‹",34,Color.WHITE,false); back.setGravity(Gravity.CENTER); h.addView(back,new LinearLayout.LayoutParams(dp(50),dp(64))); back.setOnClickListener(v->showHome());
        TextView n=tv(name,20,Color.WHITE,true); h.addView(n,new LinearLayout.LayoutParams(0,dp(64),1));
        TextView logo=tv("🦅",25,Color.WHITE,false); logo.setGravity(Gravity.CENTER); h.addView(logo,new LinearLayout.LayoutParams(dp(50),dp(64)));
        page.addView(h,new LinearLayout.LayoutParams(-1,dp(64)));
        ScrollView sv=new ScrollView(this); sv.setFillViewport(true); page.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout body=col(); pad(body,18,18,18,30); sv.addView(body,new ScrollView.LayoutParams(-1,-2));
        activeBody=body;
    }
    LinearLayout activeBody;
    TextView section(String s){ TextView t=tv(s,17,Color.DKGRAY,true); t.setPadding(0,dp(5),0,dp(12)); activeBody.addView(t,new LinearLayout.LayoutParams(-1,dp(42))); return t; }
    TextView label(String s){ TextView t=tv(s,14,Color.DKGRAY,true); t.setPadding(0,dp(4),0,dp(5)); activeBody.addView(t,new LinearLayout.LayoutParams(-1,dp(35))); return t; }
    EditText input(String hint){ EditText e=new EditText(this); e.setTextSize(15); e.setHint(hint); e.setSingleLine(true); e.setPadding(dp(14),0,dp(14),0); e.setBackground(strokeBg(Color.WHITE,0xFFD8D8D8,14)); activeBody.addView(e,new LinearLayout.LayoutParams(-1,dp(52))); return e; }
    Button action(String text){ Button b=new Button(this); b.setText(text); b.setTextSize(15); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setBackground(bg(GREEN,15)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(52)); lp.topMargin=dp(14); activeBody.addView(b,lp); return b; }
    void info(String s){ TextView t=tv(s,14,Color.DKGRAY,false); t.setGravity(Gravity.CENTER); t.setPadding(dp(15),dp(15),dp(15),dp(15)); t.setBackground(bg(Color.WHITE,16)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(82)); lp.bottomMargin=dp(12); activeBody.addView(t,lp); }

    void showHome(){ currentScreen="home"; clear();
        LinearLayout page=col(); root.addView(page,new FrameLayout.LayoutParams(-1,-1));
        // header block
        LinearLayout head=col(); head.setBackground(bg(GREEN,0)); pad(head,18,14,18,16);
        LinearLayout top=row();
        TextView logo=tv("🦅",31,Color.WHITE,false); top.addView(logo,new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout brand=col(); TextView name=tv("Eagle Telecom",22,Color.WHITE,true); TextView sub=tv("নিরাপদ ও সহজ টেলিকম সেবা",12,0xFFE5FFF2,false); brand.addView(name,new LinearLayout.LayoutParams(-1,dp(28))); brand.addView(sub,new LinearLayout.LayoutParams(-1,dp(20))); top.addView(brand,new LinearLayout.LayoutParams(0,dp(50),1));
        TextView en=tv("EN",15,Color.WHITE,true); en.setGravity(Gravity.CENTER); top.addView(en,new LinearLayout.LayoutParams(dp(44),dp(50)));
        TextView bell=tv("♧",31,Color.WHITE,false); bell.setGravity(Gravity.CENTER); top.addView(bell,new LinearLayout.LayoutParams(dp(45),dp(50)));
        TextView out=tv("⇥",31,Color.WHITE,false); out.setGravity(Gravity.CENTER); top.addView(out,new LinearLayout.LayoutParams(dp(45),dp(50))); head.addView(top,new LinearLayout.LayoutParams(-1,dp(56)));
        LinearLayout user=row(); TextView u=tv("Rosy\n016********",16,Color.WHITE,true); u.setGravity(Gravity.CENTER_VERTICAL); user.addView(u,new LinearLayout.LayoutParams(0,dp(65),1));
        TextView bal=tv("মেইন ব্যালেন্স:  "+(balanceVisible?"৳ 1,250.00":"••••••")+"  /  ট্রেড ব্যালেন্স: "+(balanceVisible?"৳ 0.00":"••••")+"   👁",14,Color.DKGRAY,true); bal.setGravity(Gravity.CENTER); bal.setBackground(bg(YELLOW,28)); user.addView(bal,new LinearLayout.LayoutParams(dp(300),dp(58))); bal.setOnClickListener(v->{balanceVisible=!balanceVisible;showHome();}); head.addView(user,new LinearLayout.LayoutParams(-1,dp(70)));
        TextView notice=tv("●   রাকিব রহমান (016********) ৭৯৯ টাকা এয়ারটেল রিচার্জ করলেন",14,Color.DKGRAY,true); notice.setPadding(dp(14),0,dp(10),0); notice.setBackground(bg(Color.WHITE,18)); head.addView(notice,new LinearLayout.LayoutParams(-1,dp(54))); LinearLayout.LayoutParams np=(LinearLayout.LayoutParams)notice.getLayoutParams(); np.topMargin=dp(5); notice.setLayoutParams(np);
        page.addView(head,new LinearLayout.LayoutParams(-1,dp(270)));
        ScrollView scroll=new ScrollView(this); LinearLayout body=col(); pad(body,18,18,18,100); scroll.addView(body); page.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        for(int row=0;row<3;row++){ LinearLayout card=row(); card.setGravity(Gravity.CENTER); card.setBackground(bg(Color.WHITE,22)); card.setElevation(dp(2)); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(190)); cp.bottomMargin=dp(16); body.addView(card,cp); for(int c=0;c<4;c++){ int idx=row*4+c; LinearLayout item=col(); item.setGravity(Gravity.CENTER); TextView ic=tv(icons[idx],32,Color.DKGRAY,false); ic.setGravity(Gravity.CENTER); item.addView(ic,new LinearLayout.LayoutParams(-1,dp(70))); TextView la=tv(labels[idx],14,Color.DKGRAY,true); la.setGravity(Gravity.CENTER); item.addView(la,new LinearLayout.LayoutParams(-1,dp(58))); card.addView(item,new LinearLayout.LayoutParams(0,-1,1)); final int x=idx; item.setOnClickListener(v->openService(x)); }}
        TextView banner=tv("🎁   ডিপোজিট বোনাস অফার\nমিনিমাম ডিপোজিট করুন — বোনাস নিয়ে নিন!\n৳ ১২৯৯   •   ৳ ২৫৯৯   •   ৳ ৪৫৯৯",19,Color.WHITE,true); banner.setGravity(Gravity.CENTER); banner.setBackground(bg(0xFF086A48,20)); body.addView(banner,new LinearLayout.LayoutParams(-1,dp(150)));
        LinearLayout nav=row(); nav.setBackgroundColor(Color.WHITE); String[] ns={"⌂\nহোম","◷\nলেনদেন","♙\nপ্রোফাইল"}; for(int i=0;i<3;i++){ TextView n=tv(ns[i],16,i==0?RED:0xFF999999,i==0); n.setGravity(Gravity.CENTER); nav.addView(n,new LinearLayout.LayoutParams(0,dp(78),1)); final int z=i; n.setOnClickListener(v->{if(z==0)showHome();else if(z==1)showTransactions();else showProfile();}); } page.addView(nav,new LinearLayout.LayoutParams(-1,dp(78)));
    }

    void openService(int i){ switch(i){
        case 0: showDeposit(); break; case 1: showMobileBanking(); break; case 2: showBankTransfer(); break; case 3: showTopup(); break;
        case 4: showGroupChat(); break; case 5: showOffers("ডাইরেক্ট অফার"); break; case 6: showBillPay(); break; case 7: showOffers("বিশেষ অফার"); break;
        case 8: showCustomerCare(); break; case 9: showReviews(); break; case 10: showTutorial(); break; default: showAbout();
    }}

    void showDeposit(){ baseWithHeader("ওয়ালেট ডিপোজিট"); section("ব্যালেন্স ডিপোজিট"); info("আপনার Main Wallet-এ টাকা যোগ করুন। Demo mode-এ আবেদনটি শুধু লোকালি দেখানো হবে।"); label("পেমেন্ট মাধ্যম"); Spinner sp=new Spinner(this); String[] a={"bKash","Nagad","Rocket","Bank"}; sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,a)); activeBody.addView(sp,new LinearLayout.LayoutParams(-1,dp(52))); label("টাকার পরিমাণ"); EditText amount=input("যেমন: 1000"); label("TrxID / Reference"); EditText trx=input("লেনদেন নম্বর লিখুন"); Button b=action("ডিপোজিট রিকোয়েস্ট পাঠান"); b.setOnClickListener(v->toast("ডিপোজিট রিকোয়েস্ট নেওয়া হয়েছে (Demo)")); }
    void showMobileBanking(){ baseWithHeader("মোবাইল ব্যাংকিং"); section("bKash / Nagad / Rocket"); info("মোবাইল ব্যাংকিং থেকে আপনার Eagle Telecom Wallet-এ টাকা যোগ বা পেমেন্ট করুন।"); for(String s:new String[]{"bKash","Nagad","Rocket"}){ Button b=action("📱  "+s); b.setOnClickListener(v->toast(s+" Screen (Demo)")); } }
    void showBankTransfer(){ baseWithHeader("ব্যাংক ট্রান্সফার"); section("Bank Transfer"); info("ব্যাংক থেকে টাকা পাঠানোর তথ্য এখানে থাকবে। আসল ব্যাংক API/merchant credentials পরে সংযুক্ত করা যাবে।"); label("ব্যাংকের নাম"); input("Bank name"); label("অ্যাকাউন্ট নম্বর"); input("Account number"); label("টাকার পরিমাণ"); input("Amount"); Button b=action("Transfer Request"); b.setOnClickListener(v->toast("Transfer request submitted (Demo)")); }
    void showTopup(){ baseWithHeader("মোবাইল টপআপ"); section("Mobile Recharge"); label("মোবাইল নম্বর"); input("01XXXXXXXXX"); label("অপারেটর"); Spinner sp=new Spinner(this); sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Grameenphone","Robi","Airtel","Banglalink","Teletalk"})); activeBody.addView(sp,new LinearLayout.LayoutParams(-1,dp(52))); label("রিচার্জের পরিমাণ"); input("Amount"); label("Recharge type"); Spinner st=new Spinner(this); st.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Regular","Internet Pack","Minute Pack","SMS Pack"})); activeBody.addView(st,new LinearLayout.LayoutParams(-1,dp(52))); Button b=action("রিচার্জ করুন"); b.setOnClickListener(v->toast("Recharge request submitted (Demo)")); }
    void showGroupChat(){ baseWithHeader("গ্রুপ চ্যাট"); section("Eagle Telecom Group"); info("এখানে এজেন্ট/ইউজারদের জন্য গ্রুপ আলোচনা থাকবে।"); for(String s:new String[]{"রিচার্জ সাপোর্ট","এজেন্ট কমিউনিটি","অফার ও আপডেট"}){ TextView t=tv("💬  "+s+"\n     সর্বশেষ মেসেজ — এখনই",15,Color.DKGRAY,false); t.setPadding(dp(15),dp(8),dp(10),dp(8)); t.setBackground(bg(Color.WHITE,16)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(72)); lp.bottomMargin=dp(10); activeBody.addView(t,lp); } }
    void showOffers(String name){ baseWithHeader(name); section("আজকের অফার"); for(int i=1;i<=5;i++){ TextView t=tv("🎁  অফার "+i+"\n     রিচার্জ/ডিপোজিটে বিশেষ বোনাস — বিস্তারিত দেখুন",15,Color.DKGRAY,true); t.setPadding(dp(16),dp(8),dp(8),dp(8)); t.setBackground(bg(Color.WHITE,16)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(82)); lp.bottomMargin=dp(10); activeBody.addView(t,lp); t.setOnClickListener(v->toast("Offer details (Demo)")); } }
    void showBillPay(){ baseWithHeader("বিল পে"); section("Bill Payment"); label("বিলের ধরন"); Spinner sp=new Spinner(this); sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"বিদ্যুৎ","গ্যাস","পানি","ইন্টারনেট","টেলিফোন"})); activeBody.addView(sp,new LinearLayout.LayoutParams(-1,dp(52))); label("Customer / Meter Number"); input("নম্বর লিখুন"); label("টাকার পরিমাণ"); input("Amount"); Button b=action("বিল পেমেন্ট করুন"); b.setOnClickListener(v->toast("Bill payment (Demo)")); }
    void showCustomerCare(){ baseWithHeader("কাস্টমার কেয়ার"); section("আমাদের সাথে যোগাযোগ"); info("আপনার সমস্যা লিখে পাঠান। প্রয়োজন হলে সাপোর্ট টিম যোগাযোগ করবে।"); label("বিষয়"); input("সমস্যার বিষয়"); label("বিস্তারিত"); EditText e=input("আপনার সমস্যাটি লিখুন"); e.setSingleLine(false); e.setGravity(Gravity.TOP); e.setPadding(dp(14),dp(10),dp(14),dp(10)); e.getLayoutParams().height=dp(120); Button b=action("সাপোর্ট টিকিট পাঠান"); b.setOnClickListener(v->toast("Support ticket created (Demo)")); }
    void showReviews(){ baseWithHeader("কাস্টমার রিভিউ"); section("Customer Reviews"); info("আপনার মতামত আমাদের সেবাকে আরও ভালো করতে সাহায্য করবে।"); for(int i=0;i<4;i++){ TextView t=tv("⭐️⭐️⭐️⭐️⭐️\nকাস্টমার "+(i+1)+" — দ্রুত সার্ভিস পেয়েছি।",15,Color.DKGRAY,false); t.setPadding(dp(16),dp(8),dp(8),dp(8)); t.setBackground(bg(Color.WHITE,16)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(82)); lp.bottomMargin=dp(10); activeBody.addView(t,lp); } label("আপনার রেটিং"); Button b=action("⭐ রিভিউ লিখুন"); b.setOnClickListener(v->toast("Review form (Demo)")); }
    void showTutorial(){ baseWithHeader("ভিডিও টিউটোরিয়াল"); section("Tutorials"); for(String s:new String[]{"কীভাবে Wallet Deposit করবেন","কীভাবে Mobile Recharge করবেন","কীভাবে Bank Transfer করবেন","কীভাবে Offer ব্যবহার করবেন"}){ Button b=action("▶  "+s); b.setOnClickListener(v->toast("Video tutorial (Demo)")); } }
    void showAbout(){ baseWithHeader("আমাদের সম্পর্কে"); section("Eagle Telecom"); info("Eagle Telecom হলো একটি টেলিকম ও ডিজিটাল সেবা অ্যাপের ডেমো কাঠামো। এখানে রিচার্জ, ওয়ালেট, ট্রান্সফার, বিল পে ও কাস্টমার সাপোর্টের আলাদা Screen রাখা হয়েছে।"); section("অ্যাপ তথ্য"); info("Version 1.0\nসাপোর্ট: Customer Care\nAPI/merchant credentials: পরে সংযুক্তযোগ্য"); }
    void showTransactions(){ baseWithHeader("লেনদেন"); section("Transaction History"); String[] tx={"Mobile Recharge — Airtel — ৳799","Wallet Deposit — bKash — ৳1,000","Bank Transfer — ৳500","Bill Pay — ৳300","Mobile Recharge — GP — ৳199"}; for(String s:tx){ TextView t=tv("●  "+s+"\n    সফল — আজ",14,Color.DKGRAY,false); t.setPadding(dp(15),dp(6),dp(8),dp(6)); t.setBackground(bg(Color.WHITE,16)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(72)); lp.bottomMargin=dp(9); activeBody.addView(t,lp); } }
    void showProfile(){ baseWithHeader("প্রোফাইল"); section("Rosy"); info("নাম: Rosy\nমোবাইল: 016********\nReferral Code: 123456"); Button p=action("✎  প্রোফাইল এডিট"); p.setOnClickListener(v->toast("Edit Profile (Demo)")); Button pass=action("🔒  পাসওয়ার্ড পরিবর্তন"); pass.setOnClickListener(v->toast("Change Password (Demo)")); Button logout=action("⇥  Logout"); logout.setOnClickListener(v->toast("Logout (Demo)")); }

    void toast(String s){ Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }
    @Override public void onBackPressed(){ if(!currentScreen.equals("home")){showHome();}else super.onBackPressed(); }
}
